
sap.ui.define([
    "sap/m/MessageToast"
], function (MessageToast) {
    'use strict';

    return {
        Submit_click: async function (oEvent) {
            // window.history.back();
            // var BPA = await cds.connect.to('INVOICE_DEST');
            // var destt = await BPA.get("/workflow/rest/v1/workflow-instances");
            


        }
    };
});
